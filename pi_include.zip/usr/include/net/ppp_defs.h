#ifndef _NET_PPP_DEFS_H
#define _NET_PPP_DEFS_H 1

#define __need_time_t
#include <time.h>

#include <asm/types.h>
#include <linux/ppp_defs.h>

#endif /* net/ppp_defs.h */
